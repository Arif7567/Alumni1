<?php
// CORS headers
header("Access-Control-Allow-Origin: *"); // সব origin থেকে request allow
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Handle OPTIONS preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once("../../config/database.php");

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['email']) || empty($data['email'])) {
    echo json_encode(["status" => "error", "message" => "Email is required."]);
    exit;
}

$email = trim($data['email']);

try {
    $stmt = $conn->prepare("SELECT user_id, email FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        // security: don't reveal if email exists
        echo json_encode(["status" => "success", "message" => "If that email exists, a reset link has been sent."]);
        exit;
    }

    // Generate temporary reset token (one-time link)
    $token = bin2hex(random_bytes(32));
    $expiry = date("Y-m-d H:i:s", strtotime("+15 minutes"));

    // Store token and expiry
    $update = $conn->prepare("UPDATE users SET reset_token = :token, reset_expiry = :expiry WHERE email = :email");
    $update->bindParam(":token", $token);
    $update->bindParam(":expiry", $expiry);
    $update->bindParam(":email", $email);
    $update->execute();

    // Return reset link (for dev/testing)
    $resetLink = "http://localhost/alumni-network-system/frontend/reset-password.html?token=" . $token;

    echo json_encode([
        "status" => "success",
        "message" => "Password reset link generated successfully.",
        "reset_link" => $resetLink
    ]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>
