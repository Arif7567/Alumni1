<?php
// --- CORS & JSON headers ---
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Handle preflight OPTIONS request
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Max-Age: 86400"); // Cache for 1 day
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit(0); // Stop here for preflight
}

// Database connection
require_once("../../config/database.php");

// Read input JSON
$data = json_decode(file_get_contents("php://input"), true);

// Validate required fields
if (!isset($data['first_name'], $data['last_name'], $data['email'], $data['password'])) {
    echo json_encode(["status" => "error", "message" => "All fields are required."]);
    exit;
}

// Sanitize inputs
$first_name = trim($data['first_name']);
$last_name  = trim($data['last_name']);
$email      = trim($data['email']);
$password   = trim($data['password']);
$role       = isset($data['role']) ? trim($data['role']) : 'student';

// Define allowed roles
$allowed_roles = ['admin', 'alumni', 'teacher', 'student'];

// Validate role
if (!in_array(strtolower($role), $allowed_roles)) {
    echo json_encode(["status" => "error", "message" => "Invalid role. Allowed roles: " . implode(', ', $allowed_roles)]);
    exit;
}

// Convert role to lowercase for consistency
$role = strtolower($role);

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(["status" => "error", "message" => "Invalid email format."]);
    exit;
}

// Validate password length
if (strlen($password) < 6) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters."]);
    exit;
}

// Hash password securely
$password_hash = password_hash($password, PASSWORD_BCRYPT);

try {
    // Check if email already exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = :email");
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "Email already registered."]);
        exit;
    }

    // Insert new user into database
    $stmt = $conn->prepare(
        "INSERT INTO users (first_name, last_name, email, password, role) 
         VALUES (:first_name, :last_name, :email, :password, :role)"
    );
    $stmt->bindParam(":first_name", $first_name);
    $stmt->bindParam(":last_name", $last_name);
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":password", $password_hash);
    $stmt->bindParam(":role", $role);

    if ($stmt->execute()) {
        // ✅ Return success message and redirect URL
        echo json_encode([
            "status" => "success",
            "message" => "Registration successful!",
            "role" => $role,
            "redirect" => "../auth/login.html"
        ]);
        exit;
    } else {
        echo json_encode(["status" => "error", "message" => "Registration failed."]);
    }

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>