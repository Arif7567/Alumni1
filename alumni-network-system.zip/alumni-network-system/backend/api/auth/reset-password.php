<?php
// CORS headers
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header("Access-Control-Allow-Credentials: true");
    header("Access-Control-Max-Age: 86400"); // cache preflight for 1 day
} else {
    header("Access-Control-Allow-Origin: *");
}

header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Handle OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once("../../config/database.php");

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['token'], $data['newPassword'])) {
    echo json_encode(["status" => "error", "message" => "Invalid request data."]);
    exit;
}

$token = trim($data['token']);
$newPassword = trim($data['newPassword']);

if (strlen($newPassword) < 6) {
    echo json_encode(["status" => "error", "message" => "Password must be at least 6 characters long."]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT user_id, reset_expiry FROM users WHERE reset_token = :token");
    $stmt->bindParam(":token", $token);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
        exit;
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (strtotime($user['reset_expiry']) < time()) {
        echo json_encode(["status" => "error", "message" => "Reset link has expired."]);
        exit;
    }

    // Hash new password
    $passwordHash = password_hash($newPassword, PASSWORD_BCRYPT);

    // Update password and clear reset token
    $update = $conn->prepare("UPDATE users SET password = :password, reset_token = NULL, reset_expiry = NULL WHERE reset_token = :token");
    $update->bindParam(":password", $passwordHash);
    $update->bindParam(":token", $token);
    $update->execute();

    echo json_encode(["status" => "success", "message" => "Password reset successful!"]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>
