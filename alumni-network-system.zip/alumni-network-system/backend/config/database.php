<?php
header("Content-Type: application/json");

$host = "localhost";
$user = "root";
$pass = "Arif7567"; // MySQL root password
$dbname = "Alumni_Networking_version_1";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Database Connection Failed: " . $e->getMessage()
    ]);
    exit;
}
?>
