<?php
class DatabaseConnection {
    private $host = "localhost";
    private $db_name = "Alumni_Networking_version_1 ";  // 👉 তোমার database নাম দাও
    private $username = "root";           // 👉 তোমার DB username দাও
    private $password = " ";               // 👉 তোমার DB password দাও
    private $conn;

    public function connect() {
        $this->conn = null;

        try {
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            die(json_encode([
                "success" => false,
                "message" => "Database connection failed: " . $e->getMessage()
            ]));
        }

        return $this->conn;
    }
}
