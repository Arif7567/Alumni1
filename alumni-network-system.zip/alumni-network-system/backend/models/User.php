<?php
require_once '../config/DatabaseConnection.php';

class User {
    private $db;
    private $table = 'users';

    public function __construct() {
        $this->db = new DatabaseConnection();
    }

    public function createUser($first_name, $last_name, $email, $password, $role = 'student') {
        $conn = $this->db->getConnection();
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO users (first_name, last_name, email, password, role) 
                VALUES (?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $first_name, $last_name, $email, $hashed_password, $role);
        
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        } else {
            $stmt->close();
            throw new Exception("Database error: " . $conn->error);
        }
    }

    public function emailExists($email) {
        $conn = $this->db->getConnection();
        
        $sql = "SELECT id FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        $exists = $stmt->num_rows > 0;
        $stmt->close();
        
        return $exists;
    }

    public function getUserByEmail($email) {
        $conn = $this->db->getConnection();
        
        $sql = "SELECT id, first_name, last_name, email, password, role, is_verified 
                FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        
        return $user;
    }
}
?>