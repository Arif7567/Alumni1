<?php
/**
 * validation.php
 * Utility functions to validate user inputs
 */

/**
 * Validate email format
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate password strength
 * - Minimum 8 characters
 * - At least 1 uppercase, 1 lowercase, 1 number
 */
function isValidPassword($password) {
    $hasUppercase = preg_match('@[A-Z]@', $password);
    $hasLowercase = preg_match('@[a-z]@', $password);
    $hasNumber    = preg_match('@[0-9]@', $password);
    $minLength    = strlen($password) >= 8;

    return $hasUppercase && $hasLowercase && $hasNumber && $minLength;
}

/**
 * Validate name (letters + spaces only, 2 to 50 chars)
 */
function isValidName($name) {
    return preg_match("/^[a-zA-Z ]{2,50}$/", $name);
}

/**
 * Validate role (Admin, Alumni, Teacher, Student)
 */
function isValidRole($role) {
    $validRoles = ['Admin', 'Alumni', 'Teacher', 'Student'];
    return in_array($role, $validRoles);
}

/**
 * Validate phone number (10-15 digits, optional + at start)
 */
function isValidPhone($phone) {
    return preg_match('/^\+?[0-9]{10,15}$/', $phone);
}
