document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", async (e) => {
            e.preventDefault();

            // Input fields
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();

            // Validation
            if (!email || !password) {
                showMessage("Please fill in all fields.", "error");
                return;
            }

            try {
                // Send login request
                const response = await fetch("http://localhost/alumni/backend/api/auth/login.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                // Handle response
                if (response.ok && data.status === "success") {
                    showMessage("Login successful! Redirecting...", "success");
                    setTimeout(() => {
                        window.location.href = "dashboard.html";
                    }, 1500);
                } else {
                    showMessage(data.message || "Invalid credentials!", "error");
                }
            } catch (error) {
                console.error("Login Error:", error);
                showMessage("Something went wrong! Please try again.", "error");
            }
        });
    }
});

/**
 * Show success or error messages dynamically
 */
function showMessage(message, type) {
    const messageBox = document.getElementById("messageBox");
    if (messageBox) {
        messageBox.textContent = message;
        messageBox.className = type === "success" ? "alert alert-success" : "alert alert-danger";
        messageBox.style.display = "block";

        setTimeout(() => {
            messageBox.style.display = "none";
        }, 3000);
    } else {
        alert(message); // fallback
    }
}
