// Enhanced Navigation and Functionality for Student Dashboard

class StudentDashboardNavigation {
    constructor() {
        this.currentPage = 'dashboard';
        this.init();
    }

    init() {
        this.setupNavigation();
        this.setupEventListeners();
        this.loadInitialData();
        this.setupAuth();
    }

    setupAuth() {
        // Check if user is logged in
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        if (!user || !user.id) {
            window.location.href = '../../auth/login.html';
            return;
        }

        // Update user info in sidebar and header
        this.updateUserInfo(user);
    }

    updateUserInfo(user) {
        // Update sidebar user info
        const sidebarUserName = document.getElementById('sidebarUserName');
        const headerUserName = document.getElementById('headerUserName');
        const welcomeMessage = document.getElementById('welcomeMessage');

        if (sidebarUserName) {
            sidebarUserName.textContent = user.first_name ? 
                `${user.first_name} ${user.last_name}` : 'Arif Sh';
        }
        if (headerUserName) {
            headerUserName.textContent = user.first_name ? 
                `${user.first_name} ${user.last_name}` : 'Arif Sh';
        }
        if (welcomeMessage && user.first_name) {
            welcomeMessage.textContent = `Welcome back, ${user.first_name}!`;
        }
    }

    setupNavigation() {
        // Setup sidebar navigation
        const menuItems = document.querySelectorAll('.sidebar-menu .menu-item');
        
        menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Remove active class from all items
                menuItems.forEach(i => i.classList.remove('active'));
                
                // Add active class to clicked item
                item.classList.add('active');
                
                // Handle navigation based on the menu item
                this.handleNavigation(item);
            });
        });

        // Setup quick action cards
        const actionCards = document.querySelectorAll('.action-card');
        actionCards.forEach(card => {
            card.addEventListener('click', () => {
                const heading = card.querySelector('h4').textContent;
                this.handleQuickAction(heading);
            });
        });
    }

    handleNavigation(menuItem) {
        const link = menuItem.querySelector('a');
        const linkText = link.querySelector('span').textContent;
        
        console.log(`Navigating to: ${linkText}`);
        
        switch(linkText) {
            case 'Dashboard':
                this.navigateToDashboard();
                break;
            case 'My Profile':
                this.navigateToProfile();
                break;
            case 'Find Alumni':
                this.navigateToFindAlumni();
                break;
            case 'Mentorship':
                this.navigateToMentorship();
                break;
            case 'Events':
                this.navigateToEvents();
                break;
            case 'Career Opportunities':
                this.navigateToCareerOpportunities();
                break;
            case 'Networking':
                this.navigateToNetworking();
                break;
            case 'Messages':
                this.navigateToMessages();
                break;
            case 'Settings':
                this.navigateToSettings();
                break;
            default:
                console.log('Unknown navigation:', linkText);
        }
    }

    handleQuickAction(actionText) {
        console.log(`Quick action: ${actionText}`);
        
        switch(actionText) {
            case 'Update Profile':
                this.navigateToProfile();
                break;
            case 'Find Alumni':
                this.navigateToFindAlumni();
                break;
            case 'Find Mentor':
                this.navigateToMentorship();
                break;
            case 'Browse Events':
                this.navigateToEvents();
                break;
            default:
                console.log('Unknown quick action:', actionText);
        }
    }

    // Navigation Methods
    navigateToDashboard() {
        this.showLoading();
        this.updatePageTitle('Student Dashboard');
        
        // Simulate loading dashboard content
        setTimeout(() => {
            this.hideLoading();
            this.showToast('Dashboard loaded successfully', 'success');
        }, 1000);
    }

    navigateToProfile() {
        this.showLoading();
        window.location.href = 'profile.html';
    }

    navigateToFindAlumni() {
        this.showLoading();
        window.location.href = 'search.html';
    }

    navigateToMentorship() {
        this.showLoading();
        window.location.href = 'mentorship.html';
    }

    navigateToEvents() {
        this.showLoading();
        window.location.href = '../../public/events.html';
    }

    navigateToCareerOpportunities() {
        this.showLoading();
        this.showModal('career-opportunities', 'Career Opportunities');
        this.loadCareerOpportunities();
    }

    navigateToNetworking() {
        this.showLoading();
        this.showModal('networking', 'Networking Hub');
        this.loadNetworkingFeatures();
    }

    navigateToMessages() {
        this.showLoading();
        this.showModal('messages', 'Messages');
        this.loadMessages();
    }

    navigateToSettings() {
        this.showLoading();
        this.showModal('settings', 'Settings');
        this.loadSettings();
    }

    setupEventListeners() {
        // Sidebar toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }

        // Notification button
        const notificationBtn = document.getElementById('notificationBtn');
        if (notificationBtn) {
            notificationBtn.addEventListener('click', () => {
                this.toggleNotifications();
            });
        }

        // Search button
        const searchBtn = document.getElementById('searchBtn');
        if (searchBtn) {
            searchBtn.addEventListener('click', () => {
                this.toggleSearch();
            });
        }

        // User dropdown
        const userDropdown = document.getElementById('userDropdown');
        if (userDropdown) {
            userDropdown.addEventListener('click', () => {
                this.toggleUserDropdown();
            });
        }

        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                this.handleLogout();
            });
        }

        // Close buttons for panels
        this.setupPanelCloseButtons();

        // Global search functionality
        this.setupGlobalSearch();

        // Refresh suggestions button
        const refreshBtn = document.getElementById('refreshSuggestions');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.refreshSuggestions();
            });
        }

        // Activity filter buttons
        this.setupActivityFilters();

        // Mark all as read
        const markAllRead = document.getElementById('markAllRead');
        if (markAllRead) {
            markAllRead.addEventListener('click', () => {
                this.markAllAsRead();
            });
        }
    }

    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('collapsed');
        
        // Save state to localStorage
        localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        
        this.showToast('Sidebar ' + (sidebar.classList.contains('collapsed') ? 'collapsed' : 'expanded'), 'info');
    }

    toggleNotifications() {
        const panel = document.getElementById('notificationPanel');
        const overlay = document.getElementById('overlay');
        
        panel.classList.toggle('active');
        overlay.classList.toggle('active');
        
        if (panel.classList.contains('active')) {
            this.loadNotifications();
        }
    }

    toggleSearch() {
        const panel = document.getElementById('searchPanel');
        const overlay = document.getElementById('overlay');
        
        panel.classList.toggle('active');
        overlay.classList.toggle('active');
        
        if (panel.classList.contains('active')) {
            document.getElementById('globalSearch').focus();
        }
    }

    toggleUserDropdown() {
        const dropdown = document.getElementById('userDropdownMenu');
        dropdown.classList.toggle('active');
    }

    setupPanelCloseButtons() {
        const closeButtons = document.querySelectorAll('.close-panel');
        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                this.closeAllPanels();
            });
        });

        // Close panels when clicking overlay
        const overlay = document.getElementById('overlay');
        if (overlay) {
            overlay.addEventListener('click', () => {
                this.closeAllPanels();
            });
        }
    }

    closeAllPanels() {
        document.getElementById('notificationPanel').classList.remove('active');
        document.getElementById('searchPanel').classList.remove('active');
        document.getElementById('userDropdownMenu').classList.remove('active');
        document.getElementById('overlay').classList.remove('active');
        
        // Close any open modals
        this.closeAllModals();
    }

    closeAllModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.remove('active');
        });
    }

    setupGlobalSearch() {
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.handleGlobalSearch(e.target.value);
            });
        }
    }

    handleGlobalSearch(query) {
        const resultsContainer = document.getElementById('searchResults');
        
        if (query.length < 2) {
            resultsContainer.innerHTML = `
                <div class="search-placeholder">
                    <i class="fas fa-search"></i>
                    <p>Start typing to search the alumni network</p>
                </div>
            `;
            return;
        }

        this.showSearchLoading();
        
        // Simulate API call
        setTimeout(() => {
            this.displaySearchResults(this.generateSearchResults(query));
            this.hideSearchLoading();
        }, 500);
    }

    generateSearchResults(query) {
        // Mock search results
        return [
            {
                type: 'alumni',
                icon: 'fas fa-user-graduate',
                title: 'Dr. Sarah Johnson',
                description: 'Senior Software Engineer at Google',
                meta: 'Computer Science, 2018'
            },
            {
                type: 'event',
                icon: 'fas fa-calendar',
                title: 'Tech Industry Workshop',
                description: 'Learn about latest tech trends',
                meta: 'Dec 15, 2024'
            },
            {
                type: 'opportunity',
                icon: 'fas fa-briefcase',
                title: 'Software Engineer Intern',
                description: 'Summer internship at Microsoft',
                meta: 'Application deadline: Jan 30, 2025'
            }
        ].filter(item => 
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.description.toLowerCase().includes(query.toLowerCase())
        );
    }

    displaySearchResults(results) {
        const resultsContainer = document.getElementById('searchResults');
        
        if (results.length === 0) {
            resultsContainer.innerHTML = `
                <div class="search-empty">
                    <i class="fas fa-search"></i>
                    <p>No results found for your search</p>
                </div>
            `;
            return;
        }

        resultsContainer.innerHTML = results.map(result => `
            <div class="search-result-item" onclick="studentDashboard.handleSearchResult('${result.type}', '${result.title}')">
                <div class="result-type ${result.type}">
                    <i class="${result.icon}"></i>
                    <span>${result.type}</span>
                </div>
                <div class="result-content">
                    <h4>${result.title}</h4>
                    <p>${result.description}</p>
                    <div class="result-meta">
                        <span>${result.meta}</span>
                    </div>
                </div>
            </div>
        `).join('');
    }

    handleSearchResult(type, title) {
        this.showToast(`Opening ${type}: ${title}`, 'info');
        this.closeAllPanels();
        
        // Navigate based on result type
        switch(type) {
            case 'alumni':
                this.navigateToFindAlumni();
                break;
            case 'event':
                this.navigateToEvents();
                break;
            case 'opportunity':
                this.navigateToCareerOpportunities();
                break;
        }
    }

    setupActivityFilters() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.filterActivities(e.target.dataset.filter);
                
                // Update active state
                filterButtons.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
    }

    filterActivities(filter) {
        const activities = document.querySelectorAll('.activity-item');
        activities.forEach(activity => {
            if (filter === 'all' || activity.classList.contains(filter)) {
                activity.style.display = 'flex';
            } else {
                activity.style.display = 'none';
            }
        });
    }

    refreshSuggestions() {
        const refreshBtn = document.getElementById('refreshSuggestions');
        refreshBtn.classList.add('loading');
        
        this.showToast('Refreshing network suggestions...', 'info');
        
        setTimeout(() => {
            this.loadNetworkSuggestions();
            refreshBtn.classList.remove('loading');
            this.showToast('Suggestions refreshed successfully', 'success');
        }, 1500);
    }

    markAllAsRead() {
        const notifications = document.querySelectorAll('.notification-item.unread');
        notifications.forEach(notification => {
            notification.classList.remove('unread');
        });
        
        // Update notification badge
        const notificationBadge = document.getElementById('notificationCount');
        if (notificationBadge) {
            notificationBadge.textContent = '0';
        }
        
        this.showToast('All notifications marked as read', 'success');
        this.closeAllPanels();
    }

    // Data Loading Methods
    loadInitialData() {
        this.showLoading();
        
        // Simulate loading all dashboard data
        setTimeout(() => {
            this.loadDashboardStats();
            this.loadRecentActivity();
            this.loadUpcomingEvents();
            this.loadMentorshipOpportunities();
            this.loadNetworkSuggestions();
            this.loadCareerOpportunitiesData();
            this.loadLearningResources();
            this.hideLoading();
        }, 2000);
    }

    loadDashboardStats() {
        // Mock data for dashboard stats
        const stats = {
            connections: 24,
            events: 3,
            messages: 5,
            mentorRequests: 2,
            notifications: 5
        };

        document.getElementById('totalConnections').textContent = stats.connections;
        document.getElementById('upcomingEvents').textContent = stats.events;
        document.getElementById('unreadMessages').textContent = stats.messages;
        document.getElementById('mentorRequests').textContent = stats.mentorRequests;
        document.getElementById('notificationCount').textContent = stats.notifications;
    }

    loadRecentActivity() {
        const activities = [
            {
                type: 'connection',
                icon: 'fas fa-user-plus',
                message: 'You connected with Dr. Sarah Johnson',
                time: '2 hours ago',
                action: 'View'
            },
            {
                type: 'event',
                icon: 'fas fa-calendar-check',
                message: 'You registered for "Career Growth Workshop"',
                time: '1 day ago',
                action: 'View'
            },
            {
                type: 'message',
                icon: 'fas fa-comment',
                message: 'New message from Alex Chen about internship',
                time: '2 days ago',
                action: 'Reply'
            }
        ];

        this.displayActivities(activities);
    }

    displayActivities(activities) {
        const container = document.getElementById('recentActivity');
        container.innerHTML = activities.map(activity => `
            <div class="activity-item ${activity.type}">
                <div class="activity-content">
                    <div class="activity-icon">
                        <i class="${activity.icon}"></i>
                    </div>
                    <div class="activity-details">
                        <div class="activity-message">${activity.message}</div>
                        <div class="activity-time">${activity.time}</div>
                    </div>
                    <button class="activity-action" onclick="studentDashboard.handleActivityAction('${activity.type}')">
                        ${activity.action}
                    </button>
                </div>
            </div>
        `).join('');
    }

    handleActivityAction(actionType) {
        this.showToast(`Handling ${actionType} action...`, 'info');
    }

    loadUpcomingEvents() {
        const events = [
            {
                title: 'Alumni Networking Mixer',
                date: 'Dec 15, 2024',
                time: '6:00 PM - 8:00 PM',
                location: 'Virtual',
                type: 'networking'
            },
            {
                title: 'Tech Industry Insights',
                date: 'Dec 20, 2024',
                time: '3:00 PM - 4:30 PM',
                location: 'Campus Hall',
                type: 'workshop'
            }
        ];

        this.displayEvents(events);
    }

    displayEvents(events) {
        const container = document.getElementById('upcomingEventsList');
        container.innerHTML = events.map(event => `
            <div class="event-item">
                <div class="event-header">
                    <h4 class="event-title">${event.title}</h4>
                    <span class="event-type ${event.type}">${event.type}</span>
                </div>
                <div class="event-details">
                    <div class="event-date">
                        <i class="fas fa-calendar"></i>
                        ${event.date} • ${event.time}
                    </div>
                    <div class="event-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${event.location}
                    </div>
                </div>
                <div class="event-actions">
                    <button class="btn-secondary" onclick="studentDashboard.viewEvent('${event.title}')">
                        <i class="fas fa-eye"></i> Details
                    </button>
                    <button class="btn-primary" onclick="studentDashboard.registerForEvent('${event.title}')">
                        <i class="fas fa-calendar-plus"></i> Register
                    </button>
                </div>
            </div>
        `).join('');
    }

    viewEvent(eventTitle) {
        this.showToast(`Viewing event: ${eventTitle}`, 'info');
    }

    registerForEvent(eventTitle) {
        this.showToast(`Registered for: ${eventTitle}`, 'success');
    }

    loadMentorshipOpportunities() {
        const mentors = [
            {
                name: 'Dr. Michael Chen',
                position: 'Senior Software Engineer at Google',
                expertise: 'Machine Learning, Career Growth',
                availability: 'Accepts 2 mentees',
                rating: 4.8
            },
            {
                name: 'Sarah Williams',
                position: 'Product Manager at Microsoft',
                expertise: 'Product Management, Leadership',
                availability: 'Accepts 1 mentee',
                rating: 4.9
            }
        ];

        this.displayMentors(mentors);
    }

    displayMentors(mentors) {
        const container = document.getElementById('mentorshipList');
        container.innerHTML = mentors.map(mentor => `
            <div class="mentorship-item">
                <div class="mentor-header">
                    <div class="mentor-avatar">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="mentor-info">
                        <h4 class="mentor-name">${mentor.name}</h4>
                        <p class="mentor-position">${mentor.position}</p>
                        <p class="mentor-expertise">${mentor.expertise}</p>
                    </div>
                </div>
                <div class="mentor-availability">
                    <span class="availability-badge">${mentor.availability}</span>
                    <div class="mentor-rating">
                        ${this.generateStarRating(mentor.rating)}
                    </div>
                </div>
                <div class="mentor-actions">
                    <button class="btn-outline" onclick="studentDashboard.viewMentorProfile('${mentor.name}')">
                        <i class="fas fa-user"></i> Profile
                    </button>
                    <button class="btn-primary" onclick="studentDashboard.requestMentorship('${mentor.name}')">
                        <i class="fas fa-handshake"></i> Connect
                    </button>
                </div>
            </div>
        `).join('');
    }

    generateStarRating(rating) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                stars += '<i class="fas fa-star"></i>';
            } else if (i - 0.5 <= rating) {
                stars += '<i class="fas fa-star-half-alt"></i>';
            } else {
                stars += '<i class="far fa-star"></i>';
            }
        }
        return stars;
    }

    viewMentorProfile(mentorName) {
        this.showToast(`Viewing profile: ${mentorName}`, 'info');
    }

    requestMentorship(mentorName) {
        this.showToast(`Mentorship request sent to ${mentorName}`, 'success');
    }

    loadNetworkSuggestions() {
        const suggestions = [
            {
                name: 'Jennifer Lopez',
                position: 'Data Scientist at Amazon',
                common: 'Same Major, Similar Interests',
                mutual: '8 mutual connections'
            },
            {
                name: 'Robert Brown',
                position: 'Startup Founder',
                common: 'Entrepreneurship Club',
                mutual: '5 mutual connections'
            }
        ];

        this.displaySuggestions(suggestions);
    }

    displaySuggestions(suggestions) {
        const container = document.getElementById('networkSuggestions');
        container.innerHTML = suggestions.map(suggestion => `
            <div class="suggestion-item">
                <div class="suggestion-content">
                    <div class="suggestion-avatar">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="suggestion-info">
                        <h4>${suggestion.name}</h4>
                        <p>${suggestion.position}</p>
                        <span class="common-interest">${suggestion.common}</span>
                        <div class="mutual-connections">
                            <i class="fas fa-users"></i>
                            ${suggestion.mutual}
                        </div>
                    </div>
                </div>
                <button class="btn-primary btn-sm" onclick="studentDashboard.sendConnectionRequest('${suggestion.name}')">
                    <i class="fas fa-user-plus"></i> Connect
                </button>
            </div>
        `).join('');
    }

    sendConnectionRequest(userName) {
        this.showToast(`Connection request sent to ${userName}`, 'success');
    }

    loadCareerOpportunitiesData() {
        const opportunities = [
            {
                title: 'Software Engineering Intern',
                company: 'Tech Innovations Inc.',
                location: 'San Francisco, CA',
                type: 'Internship',
                match: '95%'
            },
            {
                title: 'Data Analyst',
                company: 'Analytics Pro',
                location: 'Remote',
                type: 'Full-time',
                match: '88%'
            }
        ];

        this.displayOpportunities(opportunities);
    }

    displayOpportunities(opportunities) {
        const container = document.getElementById('careerOpportunities');
        container.innerHTML = opportunities.map(opportunity => `
            <div class="opportunity-item">
                <div class="opportunity-header">
                    <h4>${opportunity.title}</h4>
                    <span class="opportunity-type">${opportunity.type}</span>
                </div>
                <div class="opportunity-company">
                    <i class="fas fa-building"></i>
                    ${opportunity.company}
                </div>
                <div class="opportunity-location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${opportunity.location}
                </div>
                <div class="opportunity-meta">
                    <span class="match-score">${opportunity.match} match</span>
                    <span class="posted-date">Posted 2 days ago</span>
                </div>
                <div class="opportunity-actions">
                    <button class="btn-outline" onclick="studentDashboard.saveOpportunity('${opportunity.title}')">
                        <i class="fas fa-bookmark"></i> Save
                    </button>
                    <button class="btn-primary" onclick="studentDashboard.applyForOpportunity('${opportunity.title}')">
                        <i class="fas fa-paper-plane"></i> Apply
                    </button>
                </div>
            </div>
        `).join('');
    }

    saveOpportunity(opportunityTitle) {
        this.showToast(`Saved: ${opportunityTitle}`, 'success');
    }

    applyForOpportunity(opportunityTitle) {
        this.showToast(`Application started for: ${opportunityTitle}`, 'info');
    }

    loadLearningResources() {
        const resources = [
            {
                title: 'Career Development Guide',
                description: 'Comprehensive guide for career planning',
                type: 'PDF Guide',
                duration: '30 min read',
                icon: 'fas fa-file-pdf'
            },
            {
                title: 'Interview Preparation',
                description: 'Video series on technical interviews',
                type: 'Video Series',
                duration: '2 hours',
                icon: 'fas fa-video'
            }
        ];

        this.displayResources(resources);
    }

    displayResources(resources) {
        const container = document.getElementById('learningResources');
        container.innerHTML = resources.map(resource => `
            <div class="resource-item">
                <div class="resource-icon">
                    <i class="${resource.icon}"></i>
                </div>
                <div class="resource-content">
                    <h4>${resource.title}</h4>
                    <p>${resource.description}</p>
                    <div class="resource-meta">
                        <span class="resource-type">${resource.type}</span>
                        <span class="resource-duration">${resource.duration}</span>
                    </div>
                </div>
                <button class="btn-primary btn-sm" onclick="studentDashboard.accessResource('${resource.title}')">
                    <i class="fas fa-external-link-alt"></i> Access
                </button>
            </div>
        `).join('');
    }

    accessResource(resourceTitle) {
        this.showToast(`Accessing: ${resourceTitle}`, 'info');
    }

    loadNotifications() {
        const notifications = [
            {
                message: 'New mentorship request from Alex Thompson',
                time: '10 minutes ago',
                icon: 'fas fa-hands-helping',
                unread: true
            },
            {
                message: 'Your event registration was confirmed',
                time: '1 hour ago',
                icon: 'fas fa-calendar-check',
                unread: true
            }
        ];

        this.displayNotifications(notifications);
    }

    displayNotifications(notifications) {
        const container = document.getElementById('notificationList');
        container.innerHTML = notifications.map(notification => `
            <div class="notification-item ${notification.unread ? 'unread' : ''}">
                <div class="notification-icon">
                    <i class="${notification.icon}"></i>
                </div>
                <div class="notification-content">
                    <div class="notification-message">${notification.message}</div>
                    <div class="notification-time">${notification.time}</div>
                </div>
                ${notification.unread ? '<div class="notification-dot"></div>' : ''}
            </div>
        `).join('');
    }

    // Modal Methods
    showModal(modalType, title) {
        // Create modal if it doesn't exist
        let modal = document.getElementById(`${modalType}-modal`);
        if (!modal) {
            modal = this.createModal(modalType, title);
        }
        
        modal.classList.add('active');
        document.getElementById('overlay').classList.add('active');
    }

    createModal(modalType, title) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.id = `${modalType}-modal`;
        
        let content = '';
        switch(modalType) {
            case 'career-opportunities':
                content = this.getCareerOpportunitiesModalContent();
                break;
            case 'networking':
                content = this.getNetworkingModalContent();
                break;
            case 'messages':
                content = this.getMessagesModalContent();
                break;
            case 'settings':
                content = this.getSettingsModalContent();
                break;
        }
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="close-modal" onclick="studentDashboard.closeAllModals()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${content}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        return modal;
    }

    getCareerOpportunitiesModalContent() {
        return `
            <div class="modal-section">
                <h4>Available Opportunities</h4>
                <p>Browse through various career opportunities from our alumni network.</p>
                <div class="opportunity-list">
                    <div class="opportunity-item">
                        <h5>Software Engineer Intern</h5>
                        <p>Google - Mountain View, CA</p>
                        <button class="btn-primary">Apply Now</button>
                    </div>
                </div>
            </div>
        `;
    }

    getNetworkingModalContent() {
        return `
            <div class="modal-section">
                <h4>Networking Hub</h4>
                <p>Connect with alumni and expand your professional network.</p>
                <div class="networking-actions">
                    <button class="btn-primary">Join Networking Events</button>
                    <button class="btn-secondary">Browse Alumni Directory</button>
                </div>
            </div>
        `;
    }

    getMessagesModalContent() {
        return `
            <div class="modal-section">
                <h4>Messages</h4>
                <p>Communicate with your connections and mentors.</p>
                <div class="messages-list">
                    <div class="message-item">
                        <strong>Dr. Sarah Johnson:</strong>
                        <p>Hi! I'd be happy to discuss career opportunities...</p>
                    </div>
                </div>
            </div>
        `;
    }

    getSettingsModalContent() {
        return `
            <div class="modal-section">
                <h4>Account Settings</h4>
                <p>Manage your profile and preferences.</p>
                <div class="settings-options">
                    <button class="btn-outline">Edit Profile</button>
                    <button class="btn-outline">Privacy Settings</button>
                    <button class="btn-outline">Notification Preferences</button>
                </div>
            </div>
        `;
    }

    // Utility Methods
    showLoading() {
        // Show loading indicator
        console.log('Loading...');
    }

    hideLoading() {
        // Hide loading indicator
        console.log('Loading complete');
    }

    showSearchLoading() {
        const resultsContainer = document.getElementById('searchResults');
        resultsContainer.innerHTML = `
            <div class="search-loading">
                <i class="fas fa-spinner fa-spin"></i>
                <p>Searching...</p>
            </div>
        `;
    }

    hideSearchLoading() {
        // Loading state will be replaced by results
    }

    showToast(message, type = 'info') {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${this.getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        const container = document.getElementById('toastContainer');
        container.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
    }

    getToastIcon(type) {
        const icons = {
            'success': 'check-circle',
            'error': 'exclamation-triangle',
            'warning': 'exclamation-circle',
            'info': 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    updatePageTitle(title) {
        document.querySelector('.page-title').textContent = title;
    }

    handleLogout() {
        if (confirm('Are you sure you want to logout?')) {
            this.showLoading();
            
            // Clear user data
            localStorage.removeItem('user');
            localStorage.removeItem('isLoggedIn');
            
            setTimeout(() => {
                window.location.href = '../../auth/login.html';
            }, 1000);
        }
    }

    loadCareerOpportunities() {
        // Implementation for career opportunities
        this.showToast('Loading career opportunities...', 'info');
    }

    loadNetworkingFeatures() {
        // Implementation for networking features
        this.showToast('Loading networking features...', 'info');
    }

    loadMessages() {
        // Implementation for messages
        this.showToast('Loading messages...', 'info');
    }

    loadSettings() {
        // Implementation for settings
        this.showToast('Loading settings...', 'info');
    }
}

// Initialize the dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.studentDashboard = new StudentDashboardNavigation();
});

// Global helper functions
function navigateTo(url) {
    window.location.href = url;
}

function showHelp() {
    alert('Help and support documentation would open here.');
}